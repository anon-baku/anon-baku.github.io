from setuptools import setup

setup(name="xarm_env", version="0.0.1", install_requires=["gym"])
