# BAKU: An Efficient Transformer for Multi-Task Policy Learning

## Installation Instructions

In order to install the required dependencies, please follow the instructions provide [here](Instructions.md).
