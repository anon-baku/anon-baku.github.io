## Installation Instructions

- Clone the repository and create a conda environment using the provided `conda_env.yml` file.
```
conda env create -f conda_env.yml
```
- Activate the environment using `conda activate baku`.
- To install LIBERO, follow the instructions in the [LIBERO repository](https://github.com/Lifelong-Robot-Learning/LIBERO).
- To install Meta-World, do the following.
```
cd Metaworld
pip install -e .
```

## Instructions for Real Robot Experiments

- For running experiments on an xArm robot, install the [xArm-Python-SDK](https://github.com/xArm-Developer/xArm-Python-SDK) using the instructions provided in the repository.
- Install the xarm environment using the following command.
```
cd xarm_env
pip install -e .
```

## Instructions for Demonstrations
- For LIBERO, download the demonstrations using instructions provided in the [LIBERO repository](https://github.com/Lifelong-Robot-Learning/LIBERO).
    - Convert these demonstrations into a `.pkl` format using the following commands.
    ```
    cd baku/data_generation
    python generate_libero.py
    ```
    - Make sure to change the `DATASET_PATH` in `baku/data_generation/generate_libero.py` to the path where the demonstrations are stored.
    - The script stores the demonstration pkl files in `path/to/repo/expert_demos/libero/`. Set `root_dir` in `cfg/config.yaml` to `path/to/repo`.
- Datasets for Meta-World, DMControl, and the real world xArm Kitchen will be made public with the final version of the paper.

## Train BAKU
- Remember to set `root_dir` in `cfg/config.yaml` to `path/to/repo`.
- To train BAKU on LIBERO-90, use the following command.
```
python train.py agent=baku suite=libero dataloader=libero suite/task=libero_90 suite.hidden_dim=256
```
- To train BAKU on Meta-World, use the following command.
```
python train.py agent=baku suite=metaworld dataloader=metaworld suite.hidden_dim=256 use_proprio=false
```
- To train BAKU on DMControl, use the following command.
```
python train.py agent=baku suite=dmc dataloader=dmc suite.hidden_dim=256 obs_type=features use_proprio=false
```

## Train Baselines

### MT-ACT

- To train MT-ACT on LIBERO-90, use the following command.
```
python train.py agent=mtact suite=libero dataloader=libero suite/task=libero_90
```
- To train MT-ACT on Meta-World, use the following command.
```
python train.py agent=mtact suite=metaworld dataloader=metaworld use_proprio=false
```
- To train MT-ACT on DMControl, use the following command.
```
python train.py agent=baku suite=dmc dataloader=dmc obs_type=features use_proprio=false
```

### RT-1

- To train RT-1 on LIBERO-90, use the following command.
```
python train.py agent=rt1 suite=libero dataloader=libero suite/task=libero_90 suite.hidden_dim=512 suite.history=true suite.history_len=6 temporal_agg=false
```
- To train RT-1 on Meta-World, use the following command.
```
python train.py agent=rt1 suite=metaworld dataloader=metaworld suite.hidden_dim=512 use_proprio=false suite.history=true suite.history_len=6 temporal_agg=false
```
- To train RT-1 on DMControl, use the following command.
```
python train.py agent=rt1 suite=dmc dataloader=dmc suite.hidden_dim=512 obs_type=features use_proprio=false suite.history=true suite.history_len=6 temporal_agg=false
```