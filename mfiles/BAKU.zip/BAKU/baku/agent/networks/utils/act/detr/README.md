This part of the codebase is modified from DETR https://github.com/facebookresearch/detr under APACHE 2.0.

    @article{Carion2020EndtoEndOD,
      title={End-to-End Object Detection with Transformers},
      author={Nicolas Carion and Francisco Massa and Gabriel Synnaeve and Nicolas Usunier and Alexander Kirillov and Sergey Zagoruyko},
      journal={ArXiv},
      year={2020},
      volume={abs/2005.12872}
    }
