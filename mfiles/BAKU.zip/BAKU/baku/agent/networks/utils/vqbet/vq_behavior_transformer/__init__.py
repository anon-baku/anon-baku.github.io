from agent.networks.utils.vqbet.vq_behavior_transformer.bet import BehaviorTransformer
from agent.networks.utils.vqbet.vq_behavior_transformer.gpt import GPT, GPTConfig


__version__ = "0.1.0"
