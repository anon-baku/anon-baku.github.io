from agent.networks.utils.vqbet.vector_quantize_pytorch.vector_quantize_pytorch import (
    VectorQuantize,
)
from agent.networks.utils.vqbet.vector_quantize_pytorch.residual_vq import (
    ResidualVQ,
    GroupedResidualVQ,
)

# from vector_quantize_pytorch.random_projection_quantizer import RandomProjectionQuantizerx
